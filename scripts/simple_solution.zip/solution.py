#!/usr/bin/env python3
"""
Решение для конкурса по археологической разметке.

Этот скрипт генерирует объединенную разметку археологических объектов
на основе структуры папок датасета.

Скрипт:
1. Сканирует структуру папок входного датасета
2. Извлекает region_name, sub_region_name, markup_type из путей
3. Генерирует случайные археологические объекты (полигоны)
4. Сохраняет объединенный GeoJSON файл с результатами
"""

import os
import json
import random
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Фиксируем сиды для воспроизводимости
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# Стандартизованные названия классов из CLASS_WEIGHTS (metrics_calculator.py)
CLASS_NAMES = [
    "selishcha", "pashni", "kurgany", "karavannye_puti",
    "fortifikatsii", "gorodishcha", "arkhitektury", "dorogi",
    "yamy", "inoe", "mezha", "artefakty_lidara"
]


def is_markup_folder(folder_name: str) -> bool:
    """
    Определяет, является ли папка папкой с разметкой (её нужно игнорировать как sub_region_name)
    
    Args:
        folder_name: Имя папки
        
    Returns:
        bool: True если это папка разметки
    """
    name_lower = folder_name.lower()
    return "разметк" in name_lower


def determine_markup_type(folder_path: Path) -> str:
    """
    Определение типа разметки по пути к папке
    
    Args:
        folder_path: Путь к папке
        
    Returns:
        str: Тип разметки: 'li', 'ae', 'german_ae', 'sp_or', 'or'
    """
    path_str = str(folder_path)
    path_str_lower = path_str.lower()
    
    # Немецкая аэрофотосъёмка (проверяем первой, до обычной ae!)
    # Используем исходную строку для кириллицы из-за проблем с lower() на Windows
    if 'немецк' in path_str or '_немецкая' in path_str:
        return 'german_ae'
    
    # Спутниковые ортофото (SpOr)
    if 'spor' in path_str_lower or '_sp_or_' in path_str_lower:
        return 'sp_or'
    
    # Ортофото (Or) — обычные орто, не спутниковые
    if '_or_' in path_str_lower or path_str_lower.endswith('_or') or ' or ' in path_str_lower:
        return 'or'
    
    # LiDAR
    if 'li' in path_str_lower or 'lidar' in path_str_lower:
        return 'li'
    
    # Обычная аэрофотосъёмка
    if 'ae' in path_str_lower or 'aero' in path_str_lower:
        return 'ae'
    
    # По умолчанию считаем аэрофотосьемкой
    return 'ae'


def extract_region_and_subregion(folder_path: Path, root_dataset: Path) -> Tuple[str, str]:
    """
    Извлечение названий региона и подрегиона из пути к папке относительно корневого датасета.
    
    Args:
        folder_path: Путь к папке
        root_dataset: Корневой датасет
        
    Returns:
        Tuple[str, str]: (region_name, sub_region_name)
    """
    try:
        relative_path = folder_path.relative_to(root_dataset)
    except ValueError:
        return root_dataset.name, ""
    
    parts = list(relative_path.parts)
    if len(parts) == 0:
        return root_dataset.name, ""
    
    region_name = parts[0]
    sub_region_name = ""
    
    if len(parts) >= 2:
        candidate = parts[1]
        if not is_markup_folder(candidate):
            sub_region_name = candidate
    
    return region_name, sub_region_name


def generate_random_polygon_epsg3857() -> List[List[float]]:
    """
    Генерирует случайный полигон в координатах EPSG:3857 (Web Mercator).
    
    Координаты генерируются в разумных пределах для территории России.
    Полигон гарантированно замкнут и без самопересечений.
    
    Returns:
        List[List[float]]: Координаты полигона в формате GeoJSON [x, y]
    """
    # Границы для территории России в EPSG:3857
    # Примерно от 2500000 до 9000000 по X (восток-запад)
    # и от 5600000 до 11000000 по Y (юг-север)
    min_x = random.uniform(2500000, 9000000)
    min_y = random.uniform(5600000, 11000000)
    
    # Размеры полигона в метрах (от 5 до 200 метров)
    width = random.uniform(5, 200)
    height = random.uniform(5, 200)
    
    # Генерируем центр полигона
    center_x = min_x
    center_y = min_y
    
    # Создаем полигон с небольшими случайными отклонениями
    half_width = width / 2
    half_height = height / 2
    
    # Уменьшаем шум до 5% чтобы избежать самопересечений
    noise_factor = 0.05
    noise_w = half_width * noise_factor
    noise_h = half_height * noise_factor
    
    # Генерируем четыре угловые точки
    p1 = [center_x - half_width + random.uniform(-noise_w, noise_w), 
          center_y - half_height + random.uniform(-noise_h, noise_h)]
    p2 = [center_x + half_width + random.uniform(-noise_w, noise_w), 
          center_y - half_height + random.uniform(-noise_h, noise_h)]
    p3 = [center_x + half_width + random.uniform(-noise_w, noise_w), 
          center_y + half_height + random.uniform(-noise_h, noise_h)]
    p4 = [center_x - half_width + random.uniform(-noise_w, noise_w), 
          center_y + half_height + random.uniform(-noise_h, noise_h)]
    
    # ВАЖНО: Замыкаем полигон - последняя точка должна быть ИДЕНТИЧНА первой
    polygon = [p1, p2, p3, p4, p1]
    
    return polygon




def generate_geojson_feature(class_name: str, fid: int, region_name: str, 
                           sub_region_name: str, markup_type: str) -> Dict[str, Any]:
    """
    Генерирует одну фичу GeoJSON с обнаруженным объектом.
    
    Args:
        class_name: Название класса объекта
        fid: ID фичи
        region_name: Название региона
        sub_region_name: Название подрегиона
        markup_type: Тип разметки (ae, li, german_ae, sp_or, or)
        
    Returns:
        Dict: Фича в формате GeoJSON
    """
    # Генерируем случайную CRS из популярных для России
    possible_crs = [
        "urn:ogc:def:crs:EPSG::3857",   # Web Mercator (основная система)
        "urn:ogc:def:crs:EPSG::32636",  # UTM 36N
        "urn:ogc:def:crs:EPSG::32637",  # UTM 37N
        "urn:ogc:def:crs:EPSG::32638",  # UTM 38N
        "urn:ogc:def:crs:EPSG::3857",   # Web Mercator
    ]
    original_crs = random.choice(possible_crs)
    
    # Генерируем полигон в EPSG:3857
    polygon_coords = generate_random_polygon_epsg3857()
    geometry = {
        "type": "Polygon",
        "coordinates": [polygon_coords]
    }
    
    feature = {
        "type": "Feature",
        "properties": {
            "class_name": class_name,
            "region_name": region_name,
            "sub_region_name": sub_region_name,
            "markup_type": markup_type,
            "original_crs": original_crs,
            "crs": "urn:ogc:def:crs:EPSG::3857",
            "fid": fid,
            "confidence": round(random.uniform(0.3, 1.0), 3)
        },
        "geometry": geometry
    }
    
    return feature


def generate_features_for_folder(folder_path: Path, root_dataset: Path, 
                                current_fid: int) -> Tuple[List[Dict[str, Any]], int]:
    """
    Генерирует список features для папки датасета.
    
    Args:
        folder_path: Путь к папке
        root_dataset: Корневой датасет
        current_fid: Текущий fid для нумерации
        
    Returns:
        Tuple[List[Dict], int]: (список features, следующий fid)
    """
    # Извлекаем метаданные из пути
    region_name, sub_region_name = extract_region_and_subregion(folder_path, root_dataset)
    markup_type = determine_markup_type(folder_path)
    
    features = []
    
    # Генерируем случайное количество классов (от 0 до 4)
    num_classes = random.randint(0, 4)
    if num_classes > 0:
        selected_classes = random.sample(CLASS_NAMES, min(num_classes, len(CLASS_NAMES)))
        
        for class_name in selected_classes:
            # Случайное количество объектов этого класса (от 1 до 7)
            num_objects = random.randint(1, 7)
            
            for _ in range(num_objects):
                feature = generate_geojson_feature(
                    class_name, current_fid, region_name, 
                    sub_region_name, markup_type
                )
                features.append(feature)
                current_fid += 1
    
    return features, current_fid


def scan_dataset_folders(input_path: Path) -> List[Path]:
    """
    Рекурсивно сканирует датасет и возвращает список всех папок.
    
    Args:
        input_path: Путь к корневому датасету
        
    Returns:
        List[Path]: Список путей к папкам
    """
    folders = []
    
    for item in input_path.rglob("*"):
        if item.is_dir():
            # Добавляем только папки, которые могут содержать данные
            # Исключаем системные папки и пустые
            if not item.name.startswith('.') and not item.name.startswith('__'):
                folders.append(item)
    
    logger.info(f"Найдено {len(folders)} папок в датасете")
    return folders


def predict(input_dir: str, output_dir: str) -> Dict[str, Any]:
    """
    Основная функция для генерации объединенной разметки.
    
    Сканирует структуру папок датасета и генерирует объединенный GeoJSON файл
    с случайными археологическими объектами.
    
    Args:
        input_dir: Путь к входному датасету
        output_dir: Путь для сохранения результатов (путь к папке, куда сохранить файл result.geojson)
        
    Returns:
        Dict: Статистика обработки
    """
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    
    if not input_path.exists():
        raise ValueError(f"Входная директория не существует: {input_dir}")
    
    logger.info(f"Начинаем генерацию объединенной разметки")
    logger.info(f"Входная директория: {input_dir}")
    logger.info(f"Выходная директория: {output_dir}")
    
    # Создаем выходную директорию
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Сканируем все папки в датасете
    all_folders = scan_dataset_folders(input_path)
    
    if not all_folders:
        logger.warning(f"Не найдено папок в датасете: {input_dir}")
        # Создаем пустой файл
        all_folders = [input_path]
    
    # Создаем структуру для объединенного файла
    merged_data = {
        "type": "FeatureCollection",
        "features": []
    }
    
    current_fid = 0
    total_folders_processed = 0
    
    # Генерируем features для каждой папки
    for folder in all_folders:
        try:
            logger.info(f"Обработка папки: {folder.relative_to(input_path)}")
            
            features, current_fid = generate_features_for_folder(
                folder, input_path, current_fid
            )
            
            if features:
                merged_data["features"].extend(features)
                total_folders_processed += 1
                logger.info(f"  Сгенерировано {len(features)} features")
            
        except Exception as e:
            logger.error(f"Ошибка при обработке папки {folder}: {e}")
            continue
    
    # Сохраняем объединенный файл
    output_file = output_path / "result.geojson"
    
    logger.info(f"Сохранение объединенного файла: {output_file}")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, ensure_ascii=False, indent=2)
    
    # Статистика
    stats = {
        "total_folders": len(all_folders),
        "folders_processed": total_folders_processed,
        "total_features": len(merged_data["features"]),
        "output_file": str(output_file)
    }
    
    logger.info(f"Обработка завершена!")
    logger.info(f"Обработано папок: {total_folders_processed}/{len(all_folders)}")
    logger.info(f"Сгенерировано features: {len(merged_data['features'])}")
    logger.info(f"Результат сохранен в: {output_file}")
    
    return stats


def main():
    """
    Основная функция для запуска из командной строки.
    
    Использование:
        python solution.py <input_dir> <output_dir>
        
    Пример:
        python solution.py /Dataset /result
    """
    import sys
    
    if len(sys.argv) != 3:
        print("Ошибка: Требуется 2 аргумента")
        print("Использование: python solution.py <input_dir> <output_dir>")
        print("Пример: python solution.py /Dataset /result")
        sys.exit(1)
    
    input_dir = sys.argv[1]
    output_dir = sys.argv[2]
    
    try:
        results = predict(input_dir, output_dir)
        print("\n" + "="*50)
        print("Обработка завершена успешно!")
        print(f"Обработано папок: {results['folders_processed']}/{results['total_folders']}")
        print(f"Сгенерировано features: {results['total_features']}")
        print(f"Результат сохранен в: {results['output_file']}")
        print("="*50)
        
    except Exception as e:
        print(f"Ошибка при обработке: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()